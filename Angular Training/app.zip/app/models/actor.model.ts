export interface Actor {
  name: string;
  followers: number;
  city?: string;
}
